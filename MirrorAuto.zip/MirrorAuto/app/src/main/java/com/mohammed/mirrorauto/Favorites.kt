package com.mohammed.mirrorauto

import android.content.Context
import android.graphics.Bitmap
import androidx.core.graphics.drawable.toBitmap

/** One item of the car's app list: a single app, or two apps shown side by side ([left] is set). */
data class FavoriteEntry(val right: String, val left: String? = null) {
    val key: String get() = if (left == null) right else "$right|$left"

    companion object {
        fun parse(key: String): FavoriteEntry? {
            if (key.isBlank()) return null
            val parts = key.split("|")
            return when {
                parts.size == 1 -> FavoriteEntry(parts[0])
                parts.size == 2 && parts[0].isNotBlank() && parts[1].isNotBlank() -> FavoriteEntry(parts[0], parts[1])
                else -> null
            }
        }
    }
}

/** Apps and app pairs the user chose to launch from the car screen. */
object Favorites {
    private const val KEY = "favorites"
    private const val MAX = 12
    private const val CAR_ICON = 128

    private fun prefs(context: Context) =
        context.getSharedPreferences(CaptureService.PREFS, Context.MODE_PRIVATE)

    fun load(context: Context): List<FavoriteEntry> =
        (prefs(context).getString(KEY, "") ?: "")
            .split("\n")
            .mapNotNull { FavoriteEntry.parse(it) }

    private fun save(context: Context, list: List<FavoriteEntry>) {
        prefs(context).edit().putString(KEY, list.joinToString("\n") { it.key }).apply()
    }

    fun add(context: Context, entry: FavoriteEntry) {
        val list = load(context).filter { it != entry }.toMutableList()
        list.add(entry)
        save(context, list.takeLast(MAX))
    }

    fun remove(context: Context, entry: FavoriteEntry) {
        save(context, load(context).filter { it != entry })
    }

    private fun appLabel(context: Context, pkg: String): String {
        val pm = context.packageManager
        return try {
            pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            pkg
        }
    }

    fun label(context: Context, entry: FavoriteEntry): String {
        val left = entry.left ?: return appLabel(context, entry.right)
        return "${appLabel(context, left)} + ${appLabel(context, entry.right)}"
    }

    fun icon(context: Context, entry: FavoriteEntry): Bitmap? = try {
        val left = entry.left
        if (left == null) {
            context.packageManager.getApplicationIcon(entry.right).toBitmap(CAR_ICON, CAR_ICON)
        } else {
            Shortcuts.pairBitmap(context, entry.right, left)
        }
    } catch (e: Exception) {
        null
    }

    private fun installed(context: Context, entry: FavoriteEntry): Boolean {
        val pm = context.packageManager
        return pm.getLaunchIntentForPackage(entry.right) != null &&
            (entry.left == null || pm.getLaunchIntentForPackage(entry.left) != null)
    }

    /** The list shown on the car: the saved items first, then the apps used most recently. */
    fun carEntries(context: Context, limit: Int): List<FavoriteEntry> {
        val result = load(context).toMutableList()
        for (pkg in Shortcuts.recent(context)) {
            val entry = FavoriteEntry(pkg)
            if (entry !in result) result.add(entry)
        }
        return result.filter { installed(context, it) }.take(limit)
    }
}
