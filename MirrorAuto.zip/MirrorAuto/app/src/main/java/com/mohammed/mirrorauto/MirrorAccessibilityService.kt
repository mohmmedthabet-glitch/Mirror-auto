package com.mohammed.mirrorauto

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.Build
import android.view.Display
import android.view.accessibility.AccessibilityEvent

/** Injects taps and swipes on the phone (or on the app's virtual display) for the car screen. */
class MirrorAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    fun tap(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        dispatch(path, 50L)
    }

    fun longPress(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        dispatch(path, 700L)
    }

    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long) {
        val path = Path().apply {
            moveTo(x1, y1)
            lineTo(x2, y2)
        }
        dispatch(path, durationMs)
    }

    fun back() {
        performGlobalAction(GLOBAL_ACTION_BACK)
    }

    fun home() {
        performGlobalAction(GLOBAL_ACTION_HOME)
    }

    fun recents() {
        performGlobalAction(GLOBAL_ACTION_RECENTS)
    }

    private fun dispatch(path: Path, durationMs: Long) {
        val builder = GestureDescription.Builder()
        val target = MirrorState.displayId
        if (Build.VERSION.SDK_INT >= 32 && target != Display.DEFAULT_DISPLAY) {
            builder.setDisplayId(target)
        }
        builder.addStroke(GestureDescription.StrokeDescription(path, 0L, durationMs))
        dispatchGesture(builder.build(), null, null)
    }

    companion object {
        @Volatile
        var instance: MirrorAccessibilityService? = null
    }
}
