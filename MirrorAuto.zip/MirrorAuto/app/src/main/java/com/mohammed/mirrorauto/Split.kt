package com.mohammed.mirrorauto

import android.graphics.Bitmap
import android.graphics.RectF
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** One app of the split screen: its virtual display, the latest frame and its size. */
class SplitPane {
    @Volatile var displayId = 0
    @Volatile var width = 640
    @Volatile var height = 720

    // Guarded by MirrorState.lock
    var bitmap: Bitmap? = null
    var frameW = 0
    var frameH = 0

    // Owned by the capture service
    var virtualDisplay: VirtualDisplay? = null
    var reader: ImageReader? = null
}

/** State of the two-app split screen shown on the car. */
object SplitState {
    private const val MIN_VISIBLE = 40f

    @Volatile var active = false

    /** True after the divider was tapped: scrolling then moves the divider instead of the app. */
    @Volatile var dragging = false

    /** Position of the divider as a fraction of the car width (0 = left edge, 1 = right edge). */
    @Volatile var divider = 0.5f

    val left = SplitPane()
    val right = SplitPane()

    /** The pane that receives scrolls and the Back key (the last one that was tapped). */
    @Volatile var focused: SplitPane = right

    /** Called after the divider moved, so the service can resize the displays once it settles. */
    @Volatile var onChanged: (() -> Unit)? = null

    fun reset() {
        divider = 0.5f
        dragging = false
        focused = right
        for (pane in listOf(left, right)) {
            pane.width = 640
            pane.height = 720
            pane.displayId = 0
        }
    }

    /** Area of the car surface that belongs to the pane, or null when it is squeezed out. */
    fun region(pane: SplitPane): RectF? {
        val cw = MirrorState.carWidth.toFloat()
        val ch = MirrorState.carHeight.toFloat()
        if (cw <= 0f || ch <= 0f) return null
        val x = divider * cw
        val r = if (pane === left) RectF(0f, 0f, x, ch) else RectF(x, 0f, cw, ch)
        return if (r.width() < MIN_VISIBLE) null else r
    }

    /** Where the pane's picture is drawn inside its area (centered, aspect kept). */
    fun fit(pane: SplitPane): RectF? {
        val r = region(pane) ?: return null
        val w = pane.width.toFloat()
        val h = pane.height.toFloat()
        if (w <= 0f || h <= 0f) return null
        val scale = min(r.width() / w, r.height() / h)
        val fw = w * scale
        val fh = h * scale
        val l = r.left + (r.width() - fw) / 2f
        val t = r.top + (r.height() - fh) / 2f
        return RectF(l, t, l + fw, t + fh)
    }

    fun focus(pane: SplitPane) {
        focused = pane
        MirrorState.displayId = pane.displayId
        MirrorState.screenWidth = pane.width
        MirrorState.screenHeight = pane.height
        FrameRenderer.redraw()
    }

    /** Ratio between the focused app's pixels and car-surface pixels. */
    fun focusRatio(): Float {
        val f = fit(focused) ?: return 1f
        return if (f.width() > 0f) focused.width / f.width() else 1f
    }

    /** Moves the divider by [delta] (a fraction of the car width). */
    fun move(delta: Float) {
        divider = (divider + delta).coerceIn(0f, 1f)
        if (region(focused) == null) focus(if (focused === left) right else left)
        FrameRenderer.redraw()
        onChanged?.invoke()
    }

    /** A tap on the car screen: grabs/releases the divider, or taps inside one of the apps. */
    fun tap(x: Float, y: Float) {
        val cw = MirrorState.carWidth.toFloat()
        val dx = divider * cw
        if (abs(x - dx) <= max(36f, 0.025f * cw)) {
            dragging = !dragging
            FrameRenderer.redraw()
            return
        }
        if (dragging) {
            dragging = false
            FrameRenderer.redraw()
            return
        }
        val pane = if (x < dx) left else right
        val fit = fit(pane) ?: return
        focus(pane)
        if (!fit.contains(x, y)) return
        InputInjector.tap(
            (x - fit.left) / fit.width() * pane.width,
            (y - fit.top) / fit.height() * pane.height
        )
    }
}
