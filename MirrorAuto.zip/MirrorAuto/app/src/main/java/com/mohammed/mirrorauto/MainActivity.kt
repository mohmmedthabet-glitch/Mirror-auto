package com.mohammed.mirrorauto

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(48, 96, 48, 48)
        }

        root.addView(TextView(this).apply {
            text = "Mirror Auto"
            textSize = 26f
            gravity = Gravity.CENTER
        })

        status = TextView(this).apply {
            textSize = 16f
            setPadding(0, 32, 0, 32)
        }
        root.addView(status)

        root.addView(button("1) السماح بالإشعارات") { requestNotifications() })
        root.addView(button("2) السماح بالعرض فوق التطبيقات") { requestOverlay() })
        root.addView(button("3) إيقاف توفير البطارية للتطبيق") { requestBattery() })
        root.addView(button("4) تفعيل خدمة اللمس (Accessibility)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(button("5) بدء عكس الشاشة") { startCapture() })
        root.addView(button("إيقاف عكس الشاشة") { stopCapture() })

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun button(label: String, onClick: () -> Unit): Button =
        Button(this).apply {
            text = label
            setOnClickListener { onClick() }
        }

    private fun refreshStatus() {
        val notif = Build.VERSION.SDK_INT < 33 ||
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        val overlay = Settings.canDrawOverlays(this)
        val battery = getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName)
        val a11y = MirrorAccessibilityService.instance != null
        val running = MirrorState.running

        fun mark(ok: Boolean) = if (ok) "✅" else "❌"
        status.text = buildString {
            appendLine("${mark(notif)} الإشعارات")
            appendLine("${mark(overlay)} العرض فوق التطبيقات")
            appendLine("${mark(battery)} استثناء البطارية")
            appendLine("${mark(a11y)} خدمة اللمس")
            append("${mark(running)} عكس الشاشة يعمل")
        }
    }

    private fun requestNotifications() {
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF)
        } else {
            Toast.makeText(this, "غير مطلوب في هذا الإصدار", Toast.LENGTH_SHORT).show()
        }
    }

    private fun requestOverlay() {
        startActivity(
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
        )
    }

    private fun requestBattery() {
        startActivity(
            Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
        )
    }

    private fun startCapture() {
        val mgr = getSystemService(MediaProjectionManager::class.java)
        @Suppress("DEPRECATION")
        startActivityForResult(mgr.createScreenCaptureIntent(), REQ_CAPTURE)
    }

    private fun stopCapture() {
        startService(Intent(this, CaptureService::class.java).setAction(CaptureService.ACTION_STOP))
        refreshStatus()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_CAPTURE && resultCode == RESULT_OK && data != null) {
            startForegroundService(
                Intent(this, CaptureService::class.java)
                    .setAction(CaptureService.ACTION_START)
                    .putExtra(CaptureService.EXTRA_CODE, resultCode)
                    .putExtra(CaptureService.EXTRA_DATA, data)
            )
            Toast.makeText(this, "بدأ عكس الشاشة، افتح Mirror Auto من شاشة السيارة", Toast.LENGTH_LONG).show()
            window.decorView.postDelayed({ refreshStatus() }, 800L)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refreshStatus()
    }

    companion object {
        private const val REQ_NOTIF = 1
        private const val REQ_CAPTURE = 2
    }
}
