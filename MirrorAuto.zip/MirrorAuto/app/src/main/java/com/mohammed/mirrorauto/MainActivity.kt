package com.mohammed.mirrorauto

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var dimButton: Button
    private lateinit var screenOffButton: Button

    private val shizukuListener = Shizuku.OnRequestPermissionResultListener { _, _ ->
        runOnUiThread { refreshStatus() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(48, 96, 48, 48)
        }

        root.addView(TextView(this).apply {
            text = "Mirror Auto"
            textSize = 26f
            gravity = Gravity.CENTER
        })

        status = TextView(this).apply {
            textSize = 16f
            setPadding(0, 32, 0, 32)
        }
        root.addView(status)

        root.addView(button("1) السماح بالإشعارات") { requestNotifications() })
        root.addView(button("2) السماح بالعرض فوق التطبيقات") { requestOverlay() })
        root.addView(button("3) إيقاف توفير البطارية للتطبيق") { requestBattery() })
        root.addView(button("4) تفعيل خدمة اللمس (Accessibility)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(button("5) تفعيل Shizuku (لازم للوضع المنفصل)") { requestShizuku() })

        root.addView(section("الوضع الأول: عكس الشاشة كاملة"))
        root.addView(button("بدء عكس الشاشة") { startCapture() })
        dimButton = button("") { toggleDim() }
        root.addView(dimButton)

        root.addView(section("الوضع الثاني: تطبيق منفصل (الهاتف يبقى حرًا وتنطفئ الشاشة)"))
        root.addView(button("اختيار تطبيق (تشغيل أو إضافة اختصار)") { pickApp() })
        root.addView(button("شاشة مقسومة: تطبيقان معًا") { pickSplit() })
        root.addView(button("قائمة السيارة: حذف عناصر") { manageCarList() })
        screenOffButton = button("") { toggleScreenOff() }
        root.addView(screenOffButton)
        root.addView(button("إطفاء / تشغيل شاشة الهاتف الآن") { ScreenPower.toggle() })

        root.addView(section(""))
        root.addView(button("إيقاف") { stopCapture() })

        setContentView(ScrollView(this).apply { addView(root) })
        updateDimLabel()
        updateScreenOffLabel()
        try {
            Shizuku.addRequestPermissionResultListener(shizukuListener)
        } catch (e: Throwable) {
            // Shizuku not installed
        }
    }

    override fun onDestroy() {
        try {
            Shizuku.removeRequestPermissionResultListener(shizukuListener)
        } catch (e: Throwable) {
            // Shizuku not installed
        }
        super.onDestroy()
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun button(label: String, onClick: () -> Unit): Button =
        Button(this).apply {
            text = label
            setOnClickListener { onClick() }
        }

    private fun section(label: String): TextView =
        TextView(this).apply {
            text = label
            textSize = 15f
            setPadding(0, 40, 0, 8)
        }

    private fun prefs() = getSharedPreferences(CaptureService.PREFS, MODE_PRIVATE)

    private fun updateDimLabel() {
        val on = prefs().getBoolean(CaptureService.PREF_DIM, false)
        dimButton.text = if (on) "تعتيم شاشة الهاتف أثناء العكس: مفعّل" else "تعتيم شاشة الهاتف أثناء العكس: معطّل"
    }

    private fun updateScreenOffLabel() {
        val on = prefs().getBoolean(CaptureService.PREF_SCREEN_OFF, false)
        screenOffButton.text =
            if (on) "إطفاء الشاشة تلقائيًا عند التشغيل: مفعّل" else "إطفاء الشاشة تلقائيًا عند التشغيل: معطّل"
    }

    private fun toggleScreenOff() {
        val on = prefs().getBoolean(CaptureService.PREF_SCREEN_OFF, false)
        prefs().edit().putBoolean(CaptureService.PREF_SCREEN_OFF, !on).apply()
        updateScreenOffLabel()
    }

    private fun toggleDim() {
        val on = prefs().getBoolean(CaptureService.PREF_DIM, false)
        prefs().edit().putBoolean(CaptureService.PREF_DIM, !on).apply()
        updateDimLabel()
        Toast.makeText(this, "يُطبَّق في المرة القادمة التي تبدأ فيها العكس", Toast.LENGTH_SHORT).show()
    }

    private fun refreshStatus() {
        val notif = Build.VERSION.SDK_INT < 33 ||
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        val overlay = Settings.canDrawOverlays(this)
        val battery = getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName)
        val a11y = MirrorAccessibilityService.instance != null
        val shizuku = ShizukuShell.isReady()
        val running = MirrorState.running

        fun mark(ok: Boolean) = if (ok) "✅" else "❌"
        status.text = buildString {
            appendLine("${mark(notif)} الإشعارات")
            appendLine("${mark(overlay)} العرض فوق التطبيقات")
            appendLine("${mark(battery)} استثناء البطارية")
            appendLine("${mark(a11y)} خدمة اللمس")
            appendLine("${mark(shizuku)} Shizuku")
            append("${mark(running)} العكس يعمل")
        }
    }

    private fun requestNotifications() {
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(
                arrayOf(Manifest.permission.POST_NOTIFICATIONS, Manifest.permission.RECORD_AUDIO),
                REQ_NOTIF
            )
        } else {
            Toast.makeText(this, "غير مطلوب في هذا الإصدار", Toast.LENGTH_SHORT).show()
        }
    }

    private fun requestOverlay() {
        startActivity(
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
        )
    }

    private fun requestShizuku() {
        if (!ShizukuShell.isRunning()) {
            Toast.makeText(this, "Shizuku غير شغّال. شغّله أولًا ثم ارجع هنا", Toast.LENGTH_LONG).show()
            packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")?.let { startActivity(it) }
            return
        }
        if (ShizukuShell.isReady()) {
            Toast.makeText(this, "Shizuku جاهز", Toast.LENGTH_SHORT).show()
            refreshStatus()
            return
        }
        try {
            Shizuku.requestPermission(REQ_SHIZUKU)
        } catch (e: Throwable) {
            Toast.makeText(this, "تعذر طلب إذن Shizuku", Toast.LENGTH_LONG).show()
        }
    }

    private fun requestBattery() {
        startActivity(
            Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
        )
    }

    private fun startCapture() {
        val mgr = getSystemService(MediaProjectionManager::class.java)
        @Suppress("DEPRECATION")
        startActivityForResult(mgr.createScreenCaptureIntent(), REQ_CAPTURE)
    }

    private fun loadApps(): List<Pair<String, String>> {
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(launcher, 0)
            .filter { it.activityInfo.packageName != packageName }
            .map { it.loadLabel(packageManager).toString() to it.activityInfo.packageName }
            .distinctBy { it.second }
            .sortedBy { it.first.lowercase() }
    }

    @Suppress("DEPRECATION")
    private fun chooseApp(title: String, onPick: (label: String, pkg: String) -> Unit) {
        val apps = loadApps()
        AlertDialog.Builder(this)
            .setTitle(title)
            .setItems(apps.map { it.first }.toTypedArray()) { _, index ->
                onPick(apps[index].first, apps[index].second)
            }
            .show()
    }

    private fun requireShizuku(): Boolean {
        if (ShizukuShell.isReady()) return true
        Toast.makeText(this, "فعّل Shizuku أولًا (الزر 5)، وإلا سيرفض النظام تشغيل التطبيق", Toast.LENGTH_LONG).show()
        return false
    }

    private fun pickApp() {
        if (!requireShizuku()) return
        chooseApp("اختر التطبيق") { label, pkg -> chooseAction(label, pkg) }
    }

    private fun pickSplit() {
        if (!requireShizuku()) return
        chooseApp("التطبيق على اليمين") { labelRight, pkgRight ->
            chooseApp("التطبيق على اليسار") { labelLeft, pkgLeft ->
                if (pkgRight == pkgLeft) {
                    Toast.makeText(this, "اختر تطبيقين مختلفين", Toast.LENGTH_LONG).show()
                } else {
                    chooseSplitAction(labelRight, pkgRight, labelLeft, pkgLeft)
                }
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun chooseSplitAction(labelRight: String, pkgRight: String, labelLeft: String, pkgLeft: String) {
        AlertDialog.Builder(this)
            .setTitle("$labelLeft + $labelRight")
            .setItems(
                arrayOf("تشغيل الآن على السيارة", "إضافة اختصار للشاشة الرئيسية", "إضافة إلى قائمة السيارة")
            ) { _, which ->
                when (which) {
                    0 -> startSplit(pkgRight, pkgLeft)
                    1 -> if (Shortcuts.pinPair(this, pkgRight, pkgLeft)) {
                        Toast.makeText(this, "أكّد إضافة الاختصار في النافذة التي تظهر", Toast.LENGTH_LONG).show()
                    } else {
                        Toast.makeText(this, "الشاشة الرئيسية لا تدعم إضافة الاختصارات", Toast.LENGTH_LONG).show()
                    }
                    else -> addToCarList(FavoriteEntry(pkgRight, pkgLeft))
                }
            }
            .show()
    }

    private fun startSplit(pkgRight: String, pkgLeft: String) {
        startForegroundService(
            Intent(this, CaptureService::class.java)
                .setAction(CaptureService.ACTION_START_SPLIT)
                .putExtra(CaptureService.EXTRA_PACKAGE, pkgRight)
                .putExtra(CaptureService.EXTRA_PACKAGE2, pkgLeft)
        )
        Toast.makeText(this, "افتح Mirror Auto من شاشة السيارة", Toast.LENGTH_LONG).show()
        window.decorView.postDelayed({ refreshStatus() }, 800L)
    }

    @Suppress("DEPRECATION")
    private fun chooseAction(label: String, pkg: String) {
        AlertDialog.Builder(this)
            .setTitle(label)
            .setItems(
                arrayOf("تشغيل الآن على السيارة", "إضافة اختصار للشاشة الرئيسية", "إضافة إلى قائمة السيارة")
            ) { _, which ->
                when (which) {
                    0 -> startApp(pkg)
                    1 -> if (Shortcuts.pin(this, pkg)) {
                        Toast.makeText(this, "أكّد إضافة الاختصار في النافذة التي تظهر", Toast.LENGTH_LONG).show()
                    } else {
                        Toast.makeText(this, "الشاشة الرئيسية لا تدعم إضافة الاختصارات", Toast.LENGTH_LONG).show()
                    }
                    else -> addToCarList(FavoriteEntry(pkg))
                }
            }
            .show()
    }

    private fun addToCarList(entry: FavoriteEntry) {
        Favorites.add(this, entry)
        Toast.makeText(this, "أُضيف. يظهر في زر Apps على شاشة السيارة", Toast.LENGTH_LONG).show()
    }

    @Suppress("DEPRECATION")
    private fun manageCarList() {
        val entries = Favorites.load(this)
        if (entries.isEmpty()) {
            Toast.makeText(this, "قائمة السيارة فارغة", Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("اضغط على عنصر لحذفه من قائمة السيارة")
            .setItems(entries.map { Favorites.label(this, it) }.toTypedArray()) { _, index ->
                Favorites.remove(this, entries[index])
                Toast.makeText(this, "حُذف", Toast.LENGTH_SHORT).show()
            }
            .show()
    }

    private fun startApp(pkg: String) {
        startForegroundService(
            Intent(this, CaptureService::class.java)
                .setAction(CaptureService.ACTION_START_APP)
                .putExtra(CaptureService.EXTRA_PACKAGE, pkg)
        )
        Toast.makeText(this, "افتح Mirror Auto من شاشة السيارة", Toast.LENGTH_LONG).show()
        window.decorView.postDelayed({ refreshStatus() }, 800L)
    }

    private fun stopCapture() {
        startService(Intent(this, CaptureService::class.java).setAction(CaptureService.ACTION_STOP))
        refreshStatus()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_CAPTURE && resultCode == RESULT_OK && data != null) {
            startForegroundService(
                Intent(this, CaptureService::class.java)
                    .setAction(CaptureService.ACTION_START)
                    .putExtra(CaptureService.EXTRA_CODE, resultCode)
                    .putExtra(CaptureService.EXTRA_DATA, data)
            )
            Toast.makeText(this, "بدأ عكس الشاشة، افتح Mirror Auto من شاشة السيارة", Toast.LENGTH_LONG).show()
            window.decorView.postDelayed({ refreshStatus() }, 800L)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refreshStatus()
    }

    companion object {
        private const val REQ_NOTIF = 1
        private const val REQ_CAPTURE = 2
        private const val REQ_SHIZUKU = 3
    }
}
