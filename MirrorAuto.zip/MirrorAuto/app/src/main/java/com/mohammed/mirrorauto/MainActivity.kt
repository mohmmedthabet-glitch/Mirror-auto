package com.mohammed.mirrorauto

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var dimButton: Button

    private val shizukuListener = Shizuku.OnRequestPermissionResultListener { _, _ ->
        runOnUiThread { refreshStatus() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(48, 96, 48, 48)
        }

        root.addView(TextView(this).apply {
            text = "Mirror Auto"
            textSize = 26f
            gravity = Gravity.CENTER
        })

        status = TextView(this).apply {
            textSize = 16f
            setPadding(0, 32, 0, 32)
        }
        root.addView(status)

        root.addView(button("1) السماح بالإشعارات") { requestNotifications() })
        root.addView(button("2) السماح بالعرض فوق التطبيقات") { requestOverlay() })
        root.addView(button("3) إيقاف توفير البطارية للتطبيق") { requestBattery() })
        root.addView(button("4) تفعيل خدمة اللمس (Accessibility)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(button("5) تفعيل Shizuku (لازم للوضع المنفصل)") { requestShizuku() })

        root.addView(section("الوضع الأول: عكس الشاشة كاملة"))
        root.addView(button("بدء عكس الشاشة") { startCapture() })
        dimButton = button("") { toggleDim() }
        root.addView(dimButton)

        root.addView(section("الوضع الثاني: تطبيق منفصل (الهاتف يبقى حرًا وتنطفئ الشاشة)"))
        root.addView(button("اختيار تطبيق وتشغيله على السيارة") { pickApp() })

        root.addView(section(""))
        root.addView(button("إيقاف") { stopCapture() })

        setContentView(ScrollView(this).apply { addView(root) })
        updateDimLabel()
        try {
            Shizuku.addRequestPermissionResultListener(shizukuListener)
        } catch (e: Throwable) {
            // Shizuku not installed
        }
    }

    override fun onDestroy() {
        try {
            Shizuku.removeRequestPermissionResultListener(shizukuListener)
        } catch (e: Throwable) {
            // Shizuku not installed
        }
        super.onDestroy()
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun button(label: String, onClick: () -> Unit): Button =
        Button(this).apply {
            text = label
            setOnClickListener { onClick() }
        }

    private fun section(label: String): TextView =
        TextView(this).apply {
            text = label
            textSize = 15f
            setPadding(0, 40, 0, 8)
        }

    private fun prefs() = getSharedPreferences(CaptureService.PREFS, MODE_PRIVATE)

    private fun updateDimLabel() {
        val on = prefs().getBoolean(CaptureService.PREF_DIM, false)
        dimButton.text = if (on) "تعتيم شاشة الهاتف أثناء العكس: مفعّل" else "تعتيم شاشة الهاتف أثناء العكس: معطّل"
    }

    private fun toggleDim() {
        val on = prefs().getBoolean(CaptureService.PREF_DIM, false)
        prefs().edit().putBoolean(CaptureService.PREF_DIM, !on).apply()
        updateDimLabel()
        Toast.makeText(this, "يُطبَّق في المرة القادمة التي تبدأ فيها العكس", Toast.LENGTH_SHORT).show()
    }

    private fun refreshStatus() {
        val notif = Build.VERSION.SDK_INT < 33 ||
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        val overlay = Settings.canDrawOverlays(this)
        val battery = getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName)
        val a11y = MirrorAccessibilityService.instance != null
        val shizuku = ShizukuShell.isReady()
        val running = MirrorState.running

        fun mark(ok: Boolean) = if (ok) "✅" else "❌"
        status.text = buildString {
            appendLine("${mark(notif)} الإشعارات")
            appendLine("${mark(overlay)} العرض فوق التطبيقات")
            appendLine("${mark(battery)} استثناء البطارية")
            appendLine("${mark(a11y)} خدمة اللمس")
            appendLine("${mark(shizuku)} Shizuku")
            append("${mark(running)} العكس يعمل")
        }
    }

    private fun requestNotifications() {
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF)
        } else {
            Toast.makeText(this, "غير مطلوب في هذا الإصدار", Toast.LENGTH_SHORT).show()
        }
    }

    private fun requestOverlay() {
        startActivity(
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
        )
    }

    private fun requestShizuku() {
        if (!ShizukuShell.isRunning()) {
            Toast.makeText(this, "Shizuku غير شغّال. شغّله أولًا ثم ارجع هنا", Toast.LENGTH_LONG).show()
            packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")?.let { startActivity(it) }
            return
        }
        if (ShizukuShell.isReady()) {
            Toast.makeText(this, "Shizuku جاهز", Toast.LENGTH_SHORT).show()
            refreshStatus()
            return
        }
        try {
            Shizuku.requestPermission(REQ_SHIZUKU)
        } catch (e: Throwable) {
            Toast.makeText(this, "تعذر طلب إذن Shizuku", Toast.LENGTH_LONG).show()
        }
    }

    private fun requestBattery() {
        startActivity(
            Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
        )
    }

    private fun startCapture() {
        val mgr = getSystemService(MediaProjectionManager::class.java)
        @Suppress("DEPRECATION")
        startActivityForResult(mgr.createScreenCaptureIntent(), REQ_CAPTURE)
    }

    @Suppress("DEPRECATION")
    private fun pickApp() {
        if (!ShizukuShell.isReady()) {
            Toast.makeText(this, "فعّل Shizuku أولًا (الزر 5)، وإلا سيرفض النظام تشغيل التطبيق", Toast.LENGTH_LONG).show()
            return
        }
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = packageManager.queryIntentActivities(launcher, 0)
            .filter { it.activityInfo.packageName != packageName }
            .map { it.loadLabel(packageManager).toString() to it.activityInfo.packageName }
            .distinctBy { it.second }
            .sortedBy { it.first.lowercase() }

        AlertDialog.Builder(this)
            .setTitle("اختر التطبيق")
            .setItems(apps.map { it.first }.toTypedArray()) { _, index -> startApp(apps[index].second) }
            .show()
    }

    private fun startApp(pkg: String) {
        startForegroundService(
            Intent(this, CaptureService::class.java)
                .setAction(CaptureService.ACTION_START_APP)
                .putExtra(CaptureService.EXTRA_PACKAGE, pkg)
        )
        Toast.makeText(this, "افتح Mirror Auto من شاشة السيارة", Toast.LENGTH_LONG).show()
        window.decorView.postDelayed({ refreshStatus() }, 800L)
    }

    private fun stopCapture() {
        startService(Intent(this, CaptureService::class.java).setAction(CaptureService.ACTION_STOP))
        refreshStatus()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_CAPTURE && resultCode == RESULT_OK && data != null) {
            startForegroundService(
                Intent(this, CaptureService::class.java)
                    .setAction(CaptureService.ACTION_START)
                    .putExtra(CaptureService.EXTRA_CODE, resultCode)
                    .putExtra(CaptureService.EXTRA_DATA, data)
            )
            Toast.makeText(this, "بدأ عكس الشاشة، افتح Mirror Auto من شاشة السيارة", Toast.LENGTH_LONG).show()
            window.decorView.postDelayed({ refreshStatus() }, 800L)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refreshStatus()
    }

    companion object {
        private const val REQ_NOTIF = 1
        private const val REQ_CAPTURE = 2
        private const val REQ_SHIZUKU = 3
    }
}
