package com.mohammed.mirrorauto

import android.content.Context
import android.content.Intent
import android.content.pm.ShortcutInfo
import android.content.pm.ShortcutManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Icon
import androidx.core.graphics.drawable.toBitmap

/** Launcher shortcuts that start an app in separate mode with one tap. */
object Shortcuts {
    const val ACTION_LAUNCH = "com.mohammed.mirrorauto.LAUNCH_APP"
    const val ACTION_LAUNCH_SPLIT = "com.mohammed.mirrorauto.LAUNCH_SPLIT"
    private const val KEY_RECENT = "recent"
    private const val MAX_RECENT = 4
    private const val ICON_SIZE = 192

    private fun info(context: Context, pkg: String): ShortcutInfo? {
        val pm = context.packageManager
        return try {
            val appInfo = pm.getApplicationInfo(pkg, 0)
            val label = pm.getApplicationLabel(appInfo).toString()
            val bitmap = pm.getApplicationIcon(appInfo).toBitmap(ICON_SIZE, ICON_SIZE)
            val intent = Intent(context, LaunchActivity::class.java)
                .setAction(ACTION_LAUNCH)
                .putExtra(CaptureService.EXTRA_PACKAGE, pkg)
            ShortcutInfo.Builder(context, "app_$pkg")
                .setShortLabel(label)
                .setLongLabel("$label على السيارة")
                .setIcon(Icon.createWithBitmap(bitmap))
                .setIntent(intent)
                .build()
        } catch (e: Exception) {
            null
        }
    }

    /** Adds a shortcut for [pkg] to the home screen (the launcher asks the user to confirm). */
    fun pin(context: Context, pkg: String): Boolean {
        val manager = context.getSystemService(ShortcutManager::class.java) ?: return false
        if (!manager.isRequestPinShortcutSupported) return false
        val shortcut = info(context, pkg) ?: return false
        return manager.requestPinShortcut(shortcut, null)
    }

    /** Adds one shortcut that starts two apps together in split screen. */
    fun pinPair(context: Context, pkgRight: String, pkgLeft: String): Boolean {
        val manager = context.getSystemService(ShortcutManager::class.java) ?: return false
        if (!manager.isRequestPinShortcutSupported) return false
        val pm = context.packageManager
        return try {
            val labelRight = pm.getApplicationLabel(pm.getApplicationInfo(pkgRight, 0)).toString()
            val labelLeft = pm.getApplicationLabel(pm.getApplicationInfo(pkgLeft, 0)).toString()
            val half = ICON_SIZE / 2
            val iconRight = pm.getApplicationIcon(pkgRight).toBitmap(half, half)
            val iconLeft = pm.getApplicationIcon(pkgLeft).toBitmap(half, half)
            val combined = Bitmap.createBitmap(ICON_SIZE, ICON_SIZE, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(combined)
            canvas.drawBitmap(iconLeft, 0f, half / 2f, null)
            canvas.drawBitmap(iconRight, half.toFloat(), half / 2f, null)
            val intent = Intent(context, LaunchActivity::class.java)
                .setAction(ACTION_LAUNCH_SPLIT)
                .putExtra(CaptureService.EXTRA_PACKAGE, pkgRight)
                .putExtra(CaptureService.EXTRA_PACKAGE2, pkgLeft)
            val shortcut = ShortcutInfo.Builder(context, "split_${pkgRight}_$pkgLeft")
                .setShortLabel("$labelLeft + $labelRight")
                .setLongLabel("شاشة مقسومة: $labelLeft + $labelRight")
                .setIcon(Icon.createWithBitmap(combined))
                .setIntent(intent)
                .build()
            manager.requestPinShortcut(shortcut, null)
        } catch (e: Exception) {
            false
        }
    }

    /** Remembers the app as recently used and shows the latest ones when the app icon is long-pressed. */
    fun recordRecent(context: Context, pkg: String) {
        val prefs = context.getSharedPreferences(CaptureService.PREFS, Context.MODE_PRIVATE)
        val list = (prefs.getString(KEY_RECENT, "") ?: "")
            .split(",")
            .filter { it.isNotBlank() && it != pkg }
            .toMutableList()
        list.add(0, pkg)
        val trimmed = list.take(MAX_RECENT)
        prefs.edit().putString(KEY_RECENT, trimmed.joinToString(",")).apply()

        val manager = context.getSystemService(ShortcutManager::class.java) ?: return
        val shortcuts = trimmed.mapNotNull { info(context, it) }
        manager.dynamicShortcuts = shortcuts
    }
}
