package com.mohammed.mirrorauto

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.view.Surface

/** Shared state between the phone-side capture service and the car-side screen. */
object MirrorState {
    val lock = Any()

    // Guarded by [lock]
    var carSurface: Surface? = null
    var carWidth = 0
    var carHeight = 0
    var lastFrame: Bitmap? = null
    var frameWidth = 0
    var frameHeight = 0

    @Volatile var screenWidth = 0
    @Volatile var screenHeight = 0
    @Volatile var running = false

    /** True when a single app runs on a private virtual display instead of mirroring the whole screen. */
    @Volatile var appMode = false

    /** Display that receives injected touches (0 = the phone's main display). */
    @Volatile var displayId = 0

    /** Shows a short message on the phone; set by the capture service. */
    @Volatile var toaster: ((String) -> Unit)? = null

    /** Rectangle inside the car surface where the phone screen is drawn (letterboxed). */
    fun fitRect(): RectF? {
        val sw = screenWidth
        val sh = screenHeight
        val cw = carWidth
        val ch = carHeight
        if (sw <= 0 || sh <= 0 || cw <= 0 || ch <= 0) return null
        val scale = minOf(cw.toFloat() / sw, ch.toFloat() / sh)
        val w = sw * scale
        val h = sh * scale
        val l = (cw - w) / 2f
        val t = (ch - h) / 2f
        return RectF(l, t, l + w, t + h)
    }

    /** Converts a point on the car surface to real phone-screen pixels, or null if outside the picture. */
    fun mapToScreen(x: Float, y: Float): Pair<Float, Float>? {
        val r = fitRect() ?: return null
        if (x < r.left || x > r.right || y < r.top || y > r.bottom) return null
        return Pair(
            (x - r.left) / r.width() * screenWidth,
            (y - r.top) / r.height() * screenHeight
        )
    }

    /** Ratio between phone-screen pixels and car-surface pixels. */
    fun pixelRatio(): Float {
        val r = fitRect() ?: return 1f
        return if (r.width() > 0f) screenWidth / r.width() else 1f
    }
}

object FrameRenderer {
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
    }

    fun redraw() {
        synchronized(MirrorState.lock) {
            val surface = MirrorState.carSurface ?: return
            if (!surface.isValid) return
            val canvas: Canvas = try {
                surface.lockCanvas(null)
            } catch (e: Exception) {
                return
            }
            try {
                canvas.drawColor(Color.BLACK)
                val bmp = MirrorState.lastFrame
                val dst = MirrorState.fitRect()
                if (MirrorState.running && bmp != null && dst != null) {
                    val src = Rect(0, 0, MirrorState.frameWidth, MirrorState.frameHeight)
                    canvas.drawBitmap(bmp, src, dst, paint)
                } else {
                    textPaint.textSize = canvas.height / 14f
                    canvas.drawText(
                        "Open Mirror Auto on the phone and tap Start",
                        canvas.width / 2f,
                        canvas.height / 2f,
                        textPaint
                    )
                }
            } finally {
                try {
                    surface.unlockCanvasAndPost(canvas)
                } catch (e: Exception) {
                    // surface was destroyed while drawing
                }
            }
        }
    }
}
