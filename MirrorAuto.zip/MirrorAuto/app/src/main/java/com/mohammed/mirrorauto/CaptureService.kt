package com.mohammed.mirrorauto

import android.app.ActivityOptions
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.Display
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import kotlin.math.abs

class CaptureService : Service() {

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private var displayManager: DisplayManager? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var overlay: View? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private var currentW = 0
    private var currentH = 0

    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) {}
        override fun onDisplayRemoved(displayId: Int) {}
        override fun onDisplayChanged(displayId: Int) {
            if (displayId == Display.DEFAULT_DISPLAY) handler?.post { resizeIfNeeded() }
        }
    }

    override fun onCreate() {
        super.onCreate()
        MirrorState.toaster = { message -> toast(message) }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopCapture()
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_START -> {
                startForegroundNow(appMode = false)
                val code = intent.getIntExtra(EXTRA_CODE, 0)
                val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
                    intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(EXTRA_DATA)
                }
                if (data == null) {
                    stopSelf()
                    return START_NOT_STICKY
                }
                startCapture(code, data)
            }
            ACTION_START_SPLIT -> {
                startForegroundNow(appMode = true)
                val right = intent.getStringExtra(EXTRA_PACKAGE)
                val left = intent.getStringExtra(EXTRA_PACKAGE2)
                if (right == null || left == null) {
                    stopSelf()
                    return START_NOT_STICKY
                }
                startSplit(right, left)
            }
            ACTION_START_APP -> {
                startForegroundNow(appMode = true)
                val pkg = intent.getStringExtra(EXTRA_PACKAGE)
                if (pkg == null) {
                    stopSelf()
                    return START_NOT_STICKY
                }
                startApp(pkg)
            }
        }
        return START_NOT_STICKY
    }

    private fun startForegroundNow(appMode: Boolean) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Screen mirroring", NotificationManager.IMPORTANCE_LOW)
        )
        val stopIntent = PendingIntent.getService(
            this, 0,
            Intent(this, CaptureService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val notification = Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Mirror Auto")
            .setContentText("Mirroring to Android Auto")
            .setSmallIcon(R.drawable.ic_launcher)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(null, "Stop", stopIntent).build())
            .build()
        // App mode has no MediaProjection grant, which Android 14 requires for the projection type.
        val type = if (appMode && Build.VERSION.SDK_INT >= 34) {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        } else {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        }
        startForeground(NOTIFICATION_ID, notification, type)
    }

    private fun realMetrics(): DisplayMetrics {
        val dm = DisplayMetrics()
        val dmgr = getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        @Suppress("DEPRECATION")
        dmgr.getDisplay(Display.DEFAULT_DISPLAY).getRealMetrics(dm)
        return dm
    }

    private fun captureSize(dm: DisplayMetrics): Pair<Int, Int> {
        val scale = minOf(1f, MAX_DIMENSION / maxOf(dm.widthPixels, dm.heightPixels).toFloat())
        val w = (dm.widthPixels * scale).toInt() / 2 * 2
        val h = (dm.heightPixels * scale).toInt() / 2 * 2
        return Pair(maxOf(w, 2), maxOf(h, 2))
    }

    private fun startThread(): Handler {
        val t = HandlerThread("MirrorCapture").also { it.start() }
        thread = t
        val h = Handler(t.looper)
        handler = h
        return h
    }

    /** Mirrors the whole phone screen through MediaProjection. */
    private fun startCapture(resultCode: Int, data: Intent) {
        stopCapture()
        val h = startThread()

        val mgr = getSystemService(MediaProjectionManager::class.java)
        val p = try {
            mgr.getMediaProjection(resultCode, data)
        } catch (e: Exception) {
            null
        }
        if (p == null) {
            stopSelf()
            return
        }
        p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                stopCapture()
                stopSelf()
            }
        }, h)
        projection = p

        val dm = realMetrics()
        MirrorState.screenWidth = dm.widthPixels
        MirrorState.screenHeight = dm.heightPixels
        MirrorState.displayId = Display.DEFAULT_DISPLAY
        MirrorState.appMode = false
        val (cw, ch) = captureSize(dm)
        currentW = dm.widthPixels
        currentH = dm.heightPixels

        val r = createReader(cw, ch)
        reader = r
        virtualDisplay = p.createVirtualDisplay(
            "MirrorAuto", cw, ch, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            r.surface, null, h
        )

        displayManager = getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        displayManager?.registerDisplayListener(displayListener, h)

        acquireWakeLock()
        val dim = getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean(PREF_DIM, false)
        showOverlay(dim)

        MirrorState.running = true
        FrameRenderer.redraw()
    }

    /**
     * Runs one app on a private virtual display and mirrors only that display.
     * The phone's own screen stays free, so it can be switched off or used for other apps.
     */
    private fun startApp(pkg: String) {
        stopCapture()
        startThread()

        MirrorState.screenWidth = APP_WIDTH
        MirrorState.screenHeight = APP_HEIGHT
        val r = createReader(APP_WIDTH, APP_HEIGHT)
        reader = r

        val dmgr = getSystemService(DisplayManager::class.java)
        val vd = try {
            dmgr.createVirtualDisplay(
                "MirrorAutoApp", APP_WIDTH, APP_HEIGHT, APP_DPI, r.surface,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_PUBLIC or
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_OWN_CONTENT_ONLY
            )
        } catch (e: Exception) {
            null
        }
        if (vd == null) {
            toast("تعذر إنشاء شاشة افتراضية على هذا الهاتف")
            stopCapture()
            stopSelf()
            return
        }
        virtualDisplay = vd
        val id = vd.display.displayId
        MirrorState.displayId = id
        MirrorState.appMode = true
        MirrorState.running = true
        acquireWakeLock()
        FrameRenderer.redraw()

        try {
            Shortcuts.recordRecent(this, pkg)
        } catch (e: Exception) {
            // shortcuts are a convenience only
        }
        launchOnDisplay(pkg, id)
    }

    private fun launchOnDisplay(pkg: String, displayId: Int, allowScreenOff: Boolean = true) {
        val intent = packageManager.getLaunchIntentForPackage(pkg)
        if (intent == null) {
            toast("لا يمكن فتح هذا التطبيق")
            return
        }
        val component = intent.component?.flattenToShortString()
        if (component == null) {
            toast("لا يمكن تحديد نشاط التطبيق")
            return
        }

        Thread {
            // A normal app is not allowed to place other apps on a virtual display; the shell is.
            if (ShizukuShell.waitUntilReady(3000L)) {
                val result = ShizukuShell.run("am", "start", "--display", displayId.toString(), "-n", component)
                if (result.code != 0 || result.output.contains("Error", ignoreCase = true)) {
                    toast("فشل تشغيل التطبيق: ${result.output.take(150)}")
                    return@Thread
                }
                val screenOff = getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean(PREF_SCREEN_OFF, false)
                if (screenOff && allowScreenOff) {
                    // Give the app a moment to draw its first frame before the phone screen goes dark.
                    try {
                        Thread.sleep(3000L)
                    } catch (e: InterruptedException) {
                        return@Thread
                    }
                    if (MirrorState.running && MirrorState.appMode) {
                        ScreenPower.set(true) { worked ->
                            if (!worked) toast("تعذر إطفاء شاشة الهاتف على هذا الإصدار")
                        }
                    }
                }
            } else {
                mainHandler.post { launchWithoutShell(intent, displayId) }
            }
        }.start()
    }

    private fun launchWithoutShell(intent: Intent, displayId: Int) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_MULTIPLE_TASK)
        val options = ActivityOptions.makeBasic().setLaunchDisplayId(displayId)
        try {
            startActivity(intent, options.toBundle())
        } catch (e: Exception) {
            toast("رفض النظام تشغيل التطبيق. فعّل Shizuku (الزر 5) ثم أعد المحاولة")
        }
    }

    private fun createReader(w: Int, h: Int, pane: SplitPane? = null): ImageReader {
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        r.setOnImageAvailableListener({ ir ->
            val image = try {
                ir.acquireLatestImage()
            } catch (e: Exception) {
                null
            } ?: return@setOnImageAvailableListener
            try {
                val plane = image.planes[0]
                val rowPixels = plane.rowStride / plane.pixelStride
                synchronized(MirrorState.lock) {
                    var bmp = if (pane != null) pane.bitmap else MirrorState.lastFrame
                    if (bmp == null || bmp.isRecycled || bmp.width != rowPixels || bmp.height != image.height) {
                        bmp?.recycle()
                        bmp = Bitmap.createBitmap(rowPixels, image.height, Bitmap.Config.ARGB_8888)
                        if (pane != null) pane.bitmap = bmp else MirrorState.lastFrame = bmp
                    }
                    plane.buffer.rewind()
                    bmp.copyPixelsFromBuffer(plane.buffer)
                    if (pane != null) {
                        pane.frameW = image.width
                        pane.frameH = image.height
                    } else {
                        MirrorState.frameWidth = image.width
                        MirrorState.frameHeight = image.height
                    }
                }
                FrameRenderer.redraw()
            } finally {
                image.close()
            }
        }, handler)
        return r
    }

    private val settleRunnable = Runnable { handler?.post { settlePanes() } }

    private fun scheduleSettle() {
        mainHandler.removeCallbacks(settleRunnable)
        mainHandler.postDelayed(settleRunnable, 500L)
    }

    /** Display width that gives an app the same shape as the car area it is shown in. */
    private fun paneWidthFor(regionW: Float, regionH: Float): Int =
        ((APP_HEIGHT * regionW / regionH).toInt() / 2 * 2).coerceIn(320, 2400)

    /**
     * Runs two apps, each on its own virtual display, and shows both on the car side by side.
     * [pkgRight] fills the right pane and [pkgLeft] the left one.
     */
    private fun startSplit(pkgRight: String, pkgLeft: String) {
        stopCapture()
        startThread()
        SplitState.reset()

        val cw = MirrorState.carWidth
        val ch = MirrorState.carHeight
        val firstW = if (cw > 0 && ch > 0) paneWidthFor(cw * 0.5f, ch.toFloat()) else 640

        val dmgr = getSystemService(DisplayManager::class.java)
        val panes = listOf(SplitState.right to "MirrorAutoR", SplitState.left to "MirrorAutoL")
        for ((pane, name) in panes) {
            pane.width = firstW
            pane.height = APP_HEIGHT
            val r = createReader(firstW, APP_HEIGHT, pane)
            pane.reader = r
            val vd = try {
                dmgr.createVirtualDisplay(
                    name, firstW, APP_HEIGHT, APP_DPI, r.surface,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_PUBLIC or
                        DisplayManager.VIRTUAL_DISPLAY_FLAG_OWN_CONTENT_ONLY
                )
            } catch (e: Exception) {
                null
            }
            if (vd == null) {
                toast("تعذر إنشاء شاشتين افتراضيتين على هذا الهاتف")
                stopCapture()
                stopSelf()
                return
            }
            pane.virtualDisplay = vd
            pane.displayId = vd.display.displayId
        }

        SplitState.active = true
        MirrorState.appMode = true
        MirrorState.running = true
        SplitState.onChanged = { scheduleSettle() }
        SplitState.focus(SplitState.right)
        acquireWakeLock()

        try {
            Shortcuts.recordRecent(this, pkgLeft)
            Shortcuts.recordRecent(this, pkgRight)
        } catch (e: Exception) {
            // shortcuts are a convenience only
        }
        launchOnDisplay(pkgRight, SplitState.right.displayId, allowScreenOff = true)
        launchOnDisplay(pkgLeft, SplitState.left.displayId, allowScreenOff = false)
    }

    /** After the divider stops moving, gives each visible app a display shaped like its new area. */
    private fun settlePanes() {
        if (!SplitState.active) return
        val cw = MirrorState.carWidth
        val ch = MirrorState.carHeight
        if (cw <= 0 || ch <= 0) return
        val d = SplitState.divider
        val areas = listOf(SplitState.left to d * cw, SplitState.right to (1f - d) * cw)
        for ((pane, regionW) in areas) {
            if (regionW < cw * 0.1f) continue
            val w = paneWidthFor(regionW, ch.toFloat())
            if (abs(w - pane.width) < 24) continue
            resizePane(pane, w, APP_HEIGHT)
        }
        SplitState.focus(SplitState.focused)
    }

    private fun resizePane(pane: SplitPane, w: Int, h: Int) {
        val vd = pane.virtualDisplay ?: return
        val old = pane.reader
        val fresh = createReader(w, h, pane)
        try {
            vd.resize(w, h, APP_DPI)
            vd.surface = fresh.surface
        } catch (e: Exception) {
            fresh.close()
            return
        }
        pane.reader = fresh
        old?.close()
        pane.width = w
        pane.height = h
        synchronized(MirrorState.lock) {
            pane.bitmap?.recycle()
            pane.bitmap = null
        }
    }

    private fun resizeIfNeeded() {
        val vd = virtualDisplay ?: return
        if (MirrorState.appMode) return
        val dm = realMetrics()
        if (dm.widthPixels == currentW && dm.heightPixels == currentH) return
        currentW = dm.widthPixels
        currentH = dm.heightPixels
        MirrorState.screenWidth = dm.widthPixels
        MirrorState.screenHeight = dm.heightPixels
        val (cw, ch) = captureSize(dm)
        val old = reader
        val fresh = createReader(cw, ch)
        reader = fresh
        vd.resize(cw, ch, dm.densityDpi)
        vd.surface = fresh.surface
        old?.close()
        synchronized(MirrorState.lock) {
            MirrorState.lastFrame?.recycle()
            MirrorState.lastFrame = null
        }
    }

    private fun acquireWakeLock() {
        val pm = getSystemService(PowerManager::class.java)
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "MirrorAuto:capture").apply {
            setReferenceCounted(false)
            acquire(WAKE_LOCK_TIMEOUT_MS)
        }
    }

    /**
     * Invisible overlay that keeps the screen awake (a sleeping screen stops full-screen capture)
     * and optionally forces the lowest brightness. Touches pass straight through it.
     */
    private fun showOverlay(dim: Boolean) {
        if (!Settings.canDrawOverlays(this)) return
        mainHandler.post {
            removeOverlayNow()
            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                PixelFormat.TRANSLUCENT
            )
            params.screenBrightness = if (dim) {
                WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_OFF
            } else {
                WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
            }
            val view = View(this)
            try {
                getSystemService(WindowManager::class.java).addView(view, params)
                overlay = view
            } catch (e: Exception) {
                overlay = null
            }
        }
    }

    private fun removeOverlayNow() {
        val v = overlay ?: return
        try {
            getSystemService(WindowManager::class.java).removeView(v)
        } catch (e: Exception) {
            // already removed
        }
        overlay = null
    }

    private fun toast(message: String) {
        mainHandler.post { Toast.makeText(applicationContext, message, Toast.LENGTH_LONG).show() }
    }

    private fun stopCapture() {
        SplitState.onChanged = null
        mainHandler.removeCallbacks(settleRunnable)
        SplitState.active = false
        SplitState.dragging = false
        for (pane in listOf(SplitState.left, SplitState.right)) {
            pane.virtualDisplay?.release()
            pane.virtualDisplay = null
            pane.reader?.close()
            pane.reader = null
            synchronized(MirrorState.lock) {
                pane.bitmap?.recycle()
                pane.bitmap = null
            }
        }
        MirrorState.running = false
        MirrorState.appMode = false
        MirrorState.displayId = Display.DEFAULT_DISPLAY
        displayManager?.unregisterDisplayListener(displayListener)
        displayManager = null
        virtualDisplay?.release()
        virtualDisplay = null
        reader?.close()
        reader = null
        try {
            projection?.stop()
        } catch (e: Exception) {
            // already stopped
        }
        projection = null
        thread?.quitSafely()
        thread = null
        handler = null
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
        mainHandler.post { removeOverlayNow() }
        FrameRenderer.redraw()
    }

    override fun onDestroy() {
        stopCapture()
        // Bring the phone screen back if this app switched it off.
        if (ScreenPower.off) ScreenPower.set(false)
        MirrorState.toaster = null
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "com.mohammed.mirrorauto.START"
        const val ACTION_START_APP = "com.mohammed.mirrorauto.START_APP"
        const val ACTION_START_SPLIT = "com.mohammed.mirrorauto.START_SPLIT"
        const val ACTION_STOP = "com.mohammed.mirrorauto.STOP"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        const val EXTRA_PACKAGE = "package"
        const val EXTRA_PACKAGE2 = "package2"
        const val PREFS = "prefs"
        const val PREF_DIM = "dim"
        const val PREF_SCREEN_OFF = "screen_off"
        private const val CHANNEL_ID = "mirror"
        private const val NOTIFICATION_ID = 1
        private const val MAX_DIMENSION = 1280f
        private const val APP_WIDTH = 1280
        private const val APP_HEIGHT = 720
        private const val APP_DPI = 213
        private const val WAKE_LOCK_TIMEOUT_MS = 12L * 60L * 60L * 1000L
    }
}
