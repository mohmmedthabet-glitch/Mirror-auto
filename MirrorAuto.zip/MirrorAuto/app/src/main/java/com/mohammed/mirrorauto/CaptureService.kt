package com.mohammed.mirrorauto

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.Display

class CaptureService : Service() {

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private var displayManager: DisplayManager? = null
    private var currentW = 0
    private var currentH = 0

    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) {}
        override fun onDisplayRemoved(displayId: Int) {}
        override fun onDisplayChanged(displayId: Int) {
            if (displayId == Display.DEFAULT_DISPLAY) handler?.post { resizeIfNeeded() }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopCapture()
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_START -> {
                startForegroundNow()
                val code = intent.getIntExtra(EXTRA_CODE, 0)
                val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
                    intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(EXTRA_DATA)
                }
                if (data == null) {
                    stopSelf()
                    return START_NOT_STICKY
                }
                startCapture(code, data)
            }
        }
        return START_NOT_STICKY
    }

    private fun startForegroundNow() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Screen mirroring", NotificationManager.IMPORTANCE_LOW)
        )
        val stopIntent = PendingIntent.getService(
            this, 0,
            Intent(this, CaptureService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val notification = Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Mirror Auto")
            .setContentText("Mirroring the screen to Android Auto")
            .setSmallIcon(R.drawable.ic_launcher)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(null, "Stop", stopIntent).build())
            .build()
        startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
    }

    private fun realMetrics(): DisplayMetrics {
        val dm = DisplayMetrics()
        val dmgr = getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        @Suppress("DEPRECATION")
        dmgr.getDisplay(Display.DEFAULT_DISPLAY).getRealMetrics(dm)
        return dm
    }

    private fun captureSize(dm: DisplayMetrics): Pair<Int, Int> {
        val scale = minOf(1f, MAX_DIMENSION / maxOf(dm.widthPixels, dm.heightPixels).toFloat())
        val w = (dm.widthPixels * scale).toInt() / 2 * 2
        val h = (dm.heightPixels * scale).toInt() / 2 * 2
        return Pair(maxOf(w, 2), maxOf(h, 2))
    }

    private fun startCapture(resultCode: Int, data: Intent) {
        stopCapture()
        val t = HandlerThread("MirrorCapture").also { it.start() }
        thread = t
        val h = Handler(t.looper)
        handler = h

        val mgr = getSystemService(MediaProjectionManager::class.java)
        val p = try {
            mgr.getMediaProjection(resultCode, data)
        } catch (e: Exception) {
            null
        }
        if (p == null) {
            stopSelf()
            return
        }
        p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                stopCapture()
                stopSelf()
            }
        }, h)
        projection = p

        val dm = realMetrics()
        MirrorState.screenWidth = dm.widthPixels
        MirrorState.screenHeight = dm.heightPixels
        val (cw, ch) = captureSize(dm)
        currentW = dm.widthPixels
        currentH = dm.heightPixels

        val r = createReader(cw, ch)
        reader = r
        virtualDisplay = p.createVirtualDisplay(
            "MirrorAuto", cw, ch, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            r.surface, null, h
        )

        displayManager = getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        displayManager?.registerDisplayListener(displayListener, h)

        MirrorState.running = true
        FrameRenderer.redraw()
    }

    private fun createReader(w: Int, h: Int): ImageReader {
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        r.setOnImageAvailableListener({ ir ->
            val image = try {
                ir.acquireLatestImage()
            } catch (e: Exception) {
                null
            } ?: return@setOnImageAvailableListener
            try {
                val plane = image.planes[0]
                val rowPixels = plane.rowStride / plane.pixelStride
                synchronized(MirrorState.lock) {
                    var bmp = MirrorState.lastFrame
                    if (bmp == null || bmp.isRecycled || bmp.width != rowPixels || bmp.height != image.height) {
                        bmp?.recycle()
                        bmp = Bitmap.createBitmap(rowPixels, image.height, Bitmap.Config.ARGB_8888)
                        MirrorState.lastFrame = bmp
                    }
                    plane.buffer.rewind()
                    bmp.copyPixelsFromBuffer(plane.buffer)
                    MirrorState.frameWidth = image.width
                    MirrorState.frameHeight = image.height
                }
                FrameRenderer.redraw()
            } finally {
                image.close()
            }
        }, handler)
        return r
    }

    private fun resizeIfNeeded() {
        val vd = virtualDisplay ?: return
        val dm = realMetrics()
        if (dm.widthPixels == currentW && dm.heightPixels == currentH) return
        currentW = dm.widthPixels
        currentH = dm.heightPixels
        MirrorState.screenWidth = dm.widthPixels
        MirrorState.screenHeight = dm.heightPixels
        val (cw, ch) = captureSize(dm)
        val old = reader
        val fresh = createReader(cw, ch)
        reader = fresh
        vd.resize(cw, ch, dm.densityDpi)
        vd.surface = fresh.surface
        old?.close()
        synchronized(MirrorState.lock) {
            MirrorState.lastFrame?.recycle()
            MirrorState.lastFrame = null
        }
    }

    private fun stopCapture() {
        MirrorState.running = false
        displayManager?.unregisterDisplayListener(displayListener)
        displayManager = null
        virtualDisplay?.release()
        virtualDisplay = null
        reader?.close()
        reader = null
        try {
            projection?.stop()
        } catch (e: Exception) {
            // already stopped
        }
        projection = null
        thread?.quitSafely()
        thread = null
        handler = null
        FrameRenderer.redraw()
    }

    override fun onDestroy() {
        stopCapture()
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "com.mohammed.mirrorauto.START"
        const val ACTION_STOP = "com.mohammed.mirrorauto.STOP"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        private const val CHANNEL_ID = "mirror"
        private const val NOTIFICATION_ID = 1
        private const val MAX_DIMENSION = 1280f
    }
}
