package com.mohammed.mirrorauto

import android.content.Intent
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import androidx.activity.OnBackPressedCallback
import androidx.car.app.AppManager
import androidx.car.app.CarContext
import androidx.car.app.Screen
import androidx.car.app.SurfaceCallback
import androidx.car.app.SurfaceContainer
import androidx.car.app.model.Action
import androidx.car.app.model.ActionStrip
import androidx.car.app.model.CarColor
import androidx.car.app.model.CarIcon
import androidx.car.app.model.Template
import androidx.car.app.navigation.model.NavigationTemplate
import androidx.core.graphics.drawable.IconCompat

class MirrorScreen(carContext: CarContext) : Screen(carContext) {

    private val mainHandler = Handler(Looper.getMainLooper())

    // Scroll gestures arrive as many small deltas; collect them and dispatch one swipe when they stop.
    private var accDx = 0f
    private var accDy = 0f
    private val flushScroll = Runnable { dispatchSwipe(0f, 0f, 220L) }

    private val surfaceCallback = object : SurfaceCallback {
        override fun onSurfaceAvailable(surfaceContainer: SurfaceContainer) {
            synchronized(MirrorState.lock) {
                MirrorState.carSurface = surfaceContainer.surface
                MirrorState.carWidth = surfaceContainer.width
                MirrorState.carHeight = surfaceContainer.height
            }
            // The split panes are shaped from the car area, so re-fit them once its size is known.
            if (SplitState.active) SplitState.onChanged?.invoke()
            FrameRenderer.redraw()
        }

        override fun onSurfaceDestroyed(surfaceContainer: SurfaceContainer) {
            synchronized(MirrorState.lock) {
                MirrorState.carSurface = null
            }
        }

        override fun onVisibleAreaChanged(visibleArea: Rect) {}

        override fun onStableAreaChanged(stableArea: Rect) {}

        override fun onClick(x: Float, y: Float) {
            if (SplitState.active) {
                SplitState.tap(x, y)
                return
            }
            val p = MirrorState.mapToScreen(x, y) ?: return
            InputInjector.tap(p.first, p.second)
        }

        override fun onScroll(distanceX: Float, distanceY: Float) {
            if (SplitState.active && SplitState.dragging) {
                // The divider was grabbed: the finger moves the divider, not the app.
                val cw = MirrorState.carWidth
                if (cw > 0) SplitState.move(-distanceX / cw)
                return
            }
            val ratio = if (SplitState.active) SplitState.focusRatio() else MirrorState.pixelRatio()
            // distance is previous - current, so the finger moved in the opposite direction
            accDx += -distanceX * ratio
            accDy += -distanceY * ratio
            mainHandler.removeCallbacks(flushScroll)
            mainHandler.postDelayed(flushScroll, 120L)
        }

        override fun onFling(velocityX: Float, velocityY: Float) {
            if (SplitState.active && SplitState.dragging) return
            val ratio = if (SplitState.active) SplitState.focusRatio() else MirrorState.pixelRatio()
            mainHandler.removeCallbacks(flushScroll)
            dispatchSwipe(velocityX * FLING_FACTOR * ratio, velocityY * FLING_FACTOR * ratio, 160L)
        }

        override fun onScale(focusX: Float, focusY: Float, scaleFactor: Float) {}
    }

    init {
        carContext.getCarService(AppManager::class.java).setSurfaceCallback(surfaceCallback)

        // The car's own Back button controls the app on the screen, not the car app itself.
        carContext.onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (MirrorState.appMode || SplitState.active) {
                    InputInjector.back()
                } else {
                    // Nothing runs on a virtual display: let the car close the app as usual.
                    isEnabled = false
                    carContext.onBackPressedDispatcher.onBackPressed()
                    isEnabled = true
                }
            }
        })
    }

    private fun dispatchSwipe(extraDx: Float, extraDy: Float, durationMs: Long) {
        val w = MirrorState.screenWidth.toFloat()
        val h = MirrorState.screenHeight.toFloat()
        val dx = accDx + extraDx
        val dy = accDy + extraDy
        accDx = 0f
        accDy = 0f
        if (w <= 0f || h <= 0f) return
        if (kotlin.math.abs(dx) < 4f && kotlin.math.abs(dy) < 4f) return
        val startX = w / 2f
        val startY = h / 2f
        val endX = (startX + dx).coerceIn(1f, w - 1f)
        val endY = (startY + dy).coerceIn(1f, h - 1f)
        InputInjector.swipe(startX, startY, endX, endY, durationMs)
    }

    private fun stopCapture() {
        try {
            carContext.startService(
                Intent(carContext, CaptureService::class.java).setAction(CaptureService.ACTION_STOP)
            )
        } catch (e: Exception) {
            // service not running
        }
    }

    private fun iconAction(resId: Int, onClick: () -> Unit): Action =
        Action.Builder()
            .setIcon(CarIcon.Builder(IconCompat.createWithResource(carContext, resId)).build())
            .setOnClickListener { onClick() }
            .build()

    override fun onGetTemplate(): Template {
        val actionStrip = ActionStrip.Builder()
            .addAction(
                Action.Builder()
                    .setTitle("Apps")
                    .setOnClickListener { screenManager.push(AppsScreen(carContext)) }
                    .build()
            )
            .addAction(
                Action.Builder()
                    .setTitle("Stop")
                    .setOnClickListener { stopCapture() }
                    .build()
            )
            // Split screen only: move the divider one step toward the left or right edge.
            .addAction(iconAction(R.drawable.ic_chevron_left) { if (SplitState.active) SplitState.move(-DIVIDER_STEP) })
            .addAction(iconAction(R.drawable.ic_chevron_right) { if (SplitState.active) SplitState.move(DIVIDER_STEP) })
            .build()

        val mapActionStrip = ActionStrip.Builder()
            .addAction(Action.PAN)
            .addAction(iconAction(R.drawable.ic_back) { InputInjector.back() })
            .addAction(iconAction(R.drawable.ic_home) { MirrorAccessibilityService.instance?.home() })
            .addAction(iconAction(R.drawable.ic_power) { ScreenPower.toggle() })
            .build()

        return NavigationTemplate.Builder()
            .setActionStrip(actionStrip)
            .setMapActionStrip(mapActionStrip)
            .setBackgroundColor(CarColor.SECONDARY)
            .build()
    }

    companion object {
        private const val FLING_FACTOR = 0.18f
        private const val DIVIDER_STEP = 0.1f
    }
}
