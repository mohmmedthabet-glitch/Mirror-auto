package com.mohammed.mirrorauto

import android.content.Intent
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import androidx.car.app.AppManager
import androidx.car.app.CarContext
import androidx.car.app.Screen
import androidx.car.app.SurfaceCallback
import androidx.car.app.SurfaceContainer
import androidx.car.app.model.Action
import androidx.car.app.model.ActionStrip
import androidx.car.app.model.CarColor
import androidx.car.app.model.CarIcon
import androidx.car.app.model.Template
import androidx.car.app.navigation.model.NavigationTemplate
import androidx.core.graphics.drawable.IconCompat

class MirrorScreen(carContext: CarContext) : Screen(carContext) {

    private val mainHandler = Handler(Looper.getMainLooper())

    // Scroll gestures arrive as many small deltas; collect them and dispatch one swipe when they stop.
    private var accDx = 0f
    private var accDy = 0f
    private val flushScroll = Runnable { dispatchSwipe(0f, 0f, 220L) }

    private val surfaceCallback = object : SurfaceCallback {
        override fun onSurfaceAvailable(surfaceContainer: SurfaceContainer) {
            synchronized(MirrorState.lock) {
                MirrorState.carSurface = surfaceContainer.surface
                MirrorState.carWidth = surfaceContainer.width
                MirrorState.carHeight = surfaceContainer.height
            }
            FrameRenderer.redraw()
        }

        override fun onSurfaceDestroyed(surfaceContainer: SurfaceContainer) {
            synchronized(MirrorState.lock) {
                MirrorState.carSurface = null
            }
        }

        override fun onVisibleAreaChanged(visibleArea: Rect) {}

        override fun onStableAreaChanged(stableArea: Rect) {}

        override fun onClick(x: Float, y: Float) {
            val p = MirrorState.mapToScreen(x, y) ?: return
            MirrorAccessibilityService.instance?.tap(p.first, p.second)
        }

        override fun onScroll(distanceX: Float, distanceY: Float) {
            val ratio = MirrorState.pixelRatio()
            // distance is previous - current, so the finger moved in the opposite direction
            accDx += -distanceX * ratio
            accDy += -distanceY * ratio
            mainHandler.removeCallbacks(flushScroll)
            mainHandler.postDelayed(flushScroll, 120L)
        }

        override fun onFling(velocityX: Float, velocityY: Float) {
            val ratio = MirrorState.pixelRatio()
            mainHandler.removeCallbacks(flushScroll)
            dispatchSwipe(velocityX * FLING_FACTOR * ratio, velocityY * FLING_FACTOR * ratio, 160L)
        }

        override fun onScale(focusX: Float, focusY: Float, scaleFactor: Float) {}
    }

    init {
        carContext.getCarService(AppManager::class.java).setSurfaceCallback(surfaceCallback)
    }

    private fun dispatchSwipe(extraDx: Float, extraDy: Float, durationMs: Long) {
        val a11y = MirrorAccessibilityService.instance
        val w = MirrorState.screenWidth.toFloat()
        val h = MirrorState.screenHeight.toFloat()
        val dx = accDx + extraDx
        val dy = accDy + extraDy
        accDx = 0f
        accDy = 0f
        if (a11y == null || w <= 0f || h <= 0f) return
        if (kotlin.math.abs(dx) < 4f && kotlin.math.abs(dy) < 4f) return
        val startX = w / 2f
        val startY = h / 2f
        val endX = (startX + dx).coerceIn(1f, w - 1f)
        val endY = (startY + dy).coerceIn(1f, h - 1f)
        a11y.swipe(startX, startY, endX, endY, durationMs)
    }

    private fun stopCapture() {
        try {
            carContext.startService(
                Intent(carContext, CaptureService::class.java).setAction(CaptureService.ACTION_STOP)
            )
        } catch (e: Exception) {
            // service not running
        }
    }

    private fun iconAction(resId: Int, onClick: () -> Unit): Action =
        Action.Builder()
            .setIcon(CarIcon.Builder(IconCompat.createWithResource(carContext, resId)).build())
            .setOnClickListener { onClick() }
            .build()

    override fun onGetTemplate(): Template {
        val actionStrip = ActionStrip.Builder()
            .addAction(
                Action.Builder()
                    .setTitle("Home")
                    .setOnClickListener { MirrorAccessibilityService.instance?.home() }
                    .build()
            )
            .addAction(
                Action.Builder()
                    .setTitle("Stop")
                    .setOnClickListener { stopCapture() }
                    .build()
            )
            .build()

        val mapActionStrip = ActionStrip.Builder()
            .addAction(Action.PAN)
            .addAction(iconAction(R.drawable.ic_back) { MirrorAccessibilityService.instance?.back() })
            .addAction(iconAction(R.drawable.ic_recents) { MirrorAccessibilityService.instance?.recents() })
            .build()

        return NavigationTemplate.Builder()
            .setActionStrip(actionStrip)
            .setMapActionStrip(mapActionStrip)
            .setBackgroundColor(CarColor.SECONDARY)
            .build()
    }

    companion object {
        private const val FLING_FACTOR = 0.18f
    }
}
