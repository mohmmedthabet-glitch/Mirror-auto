package com.mohammed.mirrorauto

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Toast

/** Invisible activity opened by a shortcut: starts the chosen app in separate mode, then closes. */
class LaunchActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pkg = intent.getStringExtra(CaptureService.EXTRA_PACKAGE)
        if (pkg == null) {
            finish()
            return
        }
        // Stay open until the service has started: only a visible app may start a foreground service.
        Thread {
            val ready = ShizukuShell.waitUntilReady(3000L)
            runOnUiThread {
                if (ready) {
                    startForegroundService(
                        Intent(this, CaptureService::class.java)
                            .setAction(CaptureService.ACTION_START_APP)
                            .putExtra(CaptureService.EXTRA_PACKAGE, pkg)
                    )
                } else {
                    Toast.makeText(
                        this,
                        "Shizuku غير جاهز. شغّله ثم افتح Mirror Auto واضغط الزر 5",
                        Toast.LENGTH_LONG
                    ).show()
                }
                finish()
            }
        }.start()
    }
}
