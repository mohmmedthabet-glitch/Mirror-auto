package com.mohammed.mirrorauto

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Toast

/** Invisible activity opened by a shortcut: starts the chosen app(s) in separate mode, then closes. */
class LaunchActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pkg = intent.getStringExtra(CaptureService.EXTRA_PACKAGE)
        val pkg2 = intent.getStringExtra(CaptureService.EXTRA_PACKAGE2)
        val split = intent.action == Shortcuts.ACTION_LAUNCH_SPLIT
        if (pkg == null || (split && pkg2 == null)) {
            finish()
            return
        }
        // Stay open until the service has started: only a visible app may start a foreground service.
        Thread {
            val ready = ShizukuShell.waitUntilReady(3000L)
            runOnUiThread {
                if (ready) {
                    val service = Intent(this, CaptureService::class.java)
                        .putExtra(CaptureService.EXTRA_PACKAGE, pkg)
                    if (split) {
                        service.setAction(CaptureService.ACTION_START_SPLIT)
                            .putExtra(CaptureService.EXTRA_PACKAGE2, pkg2)
                    } else {
                        service.setAction(CaptureService.ACTION_START_APP)
                    }
                    startForegroundService(service)
                } else {
                    Toast.makeText(
                        this,
                        "Shizuku غير جاهز. شغّله ثم افتح Mirror Auto واضغط الزر 5",
                        Toast.LENGTH_LONG
                    ).show()
                }
                finish()
            }
        }.start()
    }
}
