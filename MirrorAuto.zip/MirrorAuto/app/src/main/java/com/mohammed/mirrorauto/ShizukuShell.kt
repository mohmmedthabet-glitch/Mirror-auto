package com.mohammed.mirrorauto

import android.content.pm.PackageManager
import android.view.Display
import rikka.shizuku.Shizuku
import java.util.concurrent.Executors

/** Runs shell commands with shell privileges through Shizuku. */
object ShizukuShell {

    class Result(val code: Int, val output: String)

    /** Shizuku is running (binder reachable), regardless of whether this app has permission. */
    fun isRunning(): Boolean = try {
        Shizuku.pingBinder()
    } catch (e: Throwable) {
        false
    }

    /** Shizuku is running and this app was granted permission. */
    fun isReady(): Boolean = try {
        Shizuku.pingBinder() && !Shizuku.isPreV11() &&
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) {
        false
    }

    /** Polls until Shizuku is ready; a freshly started process receives the Shizuku binder a moment late. */
    fun waitUntilReady(timeoutMs: Long): Boolean {
        val end = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < end) {
            if (isReady()) return true
            try {
                Thread.sleep(100L)
            } catch (e: InterruptedException) {
                return isReady()
            }
        }
        return isReady()
    }

    // newProcess is not part of the public API surface any more, so it is reached by reflection.
    private val newProcess by lazy {
        Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java,
            Array<String>::class.java,
            String::class.java
        ).apply { isAccessible = true }
    }

    /** Blocking. Call from a background thread. */
    fun run(vararg cmd: String): Result {
        return try {
            val process = newProcess.invoke(null, arrayOf(*cmd), null, null) as Process
            val out = process.inputStream.bufferedReader().readText()
            val err = process.errorStream.bufferedReader().readText()
            val code = process.waitFor()
            Result(code, (out + err).trim())
        } catch (e: Throwable) {
            Result(-1, e.message ?: e.javaClass.simpleName)
        }
    }
}

/**
 * Sends touch and key input to the mirrored surface.
 * In app mode with Shizuku it uses `input ... -d <display>` (reliable on a virtual display);
 * otherwise it falls back to the accessibility service.
 */
object InputInjector {
    private val executor = Executors.newSingleThreadExecutor()
    @Volatile private var lastReport = 0L

    /** Touches go through the shell only when the target is an app's virtual display, not the phone itself. */
    private fun onVirtualDisplay() = MirrorState.displayId != Display.DEFAULT_DISPLAY

    private fun useShell() = onVirtualDisplay() && ShizukuShell.isReady()

    /**
     * The position of the `-d` option differs between Android versions, so three
     * argument orders are tried until one runs without printing anything.
     */
    private fun runInput(source: String, vararg args: String) {
        val id = MirrorState.displayId.toString()
        executor.execute {
            val attempts = listOf(
                arrayOf("input", source, "-d", id, *args),
                arrayOf("input", "-d", id, source, *args),
                arrayOf("input", "-d", id, *args)
            )
            var last: ShizukuShell.Result? = null
            for (attempt in attempts) {
                val result = ShizukuShell.run(*attempt)
                last = result
                if (result.code == 0 && result.output.isEmpty()) return@execute
            }
            report(last)
        }
    }

    private fun report(result: ShizukuShell.Result?) {
        val now = System.currentTimeMillis()
        if (now - lastReport < 5000L) return
        lastReport = now
        MirrorState.toaster?.invoke("فشل إرسال اللمس: ${result?.output.orEmpty().take(150)}")
    }

    fun tap(x: Float, y: Float) {
        if (useShell()) {
            runInput("touchscreen", "tap", x.toInt().toString(), y.toInt().toString())
        } else {
            MirrorAccessibilityService.instance?.tap(x, y)
        }
    }

    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long) {
        if (useShell()) {
            runInput(
                "touchscreen", "swipe",
                x1.toInt().toString(), y1.toInt().toString(),
                x2.toInt().toString(), y2.toInt().toString(),
                durationMs.toString()
            )
        } else {
            MirrorAccessibilityService.instance?.swipe(x1, y1, x2, y2, durationMs)
        }
    }

    /**
     * Back goes to the app on the virtual display only. While an app runs there it is never sent
     * to the phone itself, even if Shizuku is missing; the global Back is used only when the
     * whole phone screen is being mirrored.
     */
    fun back() {
        if (onVirtualDisplay()) {
            if (ShizukuShell.isReady()) {
                runInput("keyboard", "keyevent", "4")
            } else {
                MirrorState.toaster?.invoke("Shizuku غير جاهز، لا يمكن إرسال Back للتطبيق")
            }
        } else {
            MirrorAccessibilityService.instance?.back()
        }
    }
}

/** Turns the phone's own screen off and on while the app keeps running on its virtual display. */
object ScreenPower {
    @Volatile var off = false
        private set

    private fun ok(r: ShizukuShell.Result): Boolean =
        r.code == 0 &&
            !r.output.contains("error", ignoreCase = true) &&
            !r.output.contains("unknown", ignoreCase = true) &&
            !r.output.contains("exception", ignoreCase = true)

    /**
     * First choice is the display power command, which leaves the phone awake (apps keep running).
     * If this Android version lacks it, the sleep key is used instead.
     */
    private fun turnOffNow(): Boolean {
        if (ok(ShizukuShell.run("cmd", "display", "power-off", "0"))) return true
        return ok(ShizukuShell.run("input", "keyevent", "223"))
    }

    private fun turnOnNow(): Boolean {
        if (ok(ShizukuShell.run("cmd", "display", "power-on", "0"))) return true
        return ok(ShizukuShell.run("input", "keyevent", "224"))
    }

    /** Runs on a background thread. [onDone] receives whether the command worked. */
    fun set(turnOff: Boolean, onDone: ((Boolean) -> Unit)? = null) {
        Thread {
            val worked = if (!ShizukuShell.isReady()) false else if (turnOff) turnOffNow() else turnOnNow()
            if (worked) off = turnOff
            onDone?.invoke(worked)
        }.start()
    }

    fun toggle() {
        val target = !off
        set(target) { worked ->
            if (!worked) {
                MirrorState.toaster?.invoke(
                    if (target) "تعذر إطفاء شاشة الهاتف على هذا الإصدار" else "تعذر تشغيل شاشة الهاتف"
                )
            }
        }
    }
}
