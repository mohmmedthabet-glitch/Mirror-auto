package com.mohammed.mirrorauto

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku
import java.util.concurrent.Executors

/** Runs shell commands with shell privileges through Shizuku. */
object ShizukuShell {

    class Result(val code: Int, val output: String)

    /** Shizuku is running (binder reachable), regardless of whether this app has permission. */
    fun isRunning(): Boolean = try {
        Shizuku.pingBinder()
    } catch (e: Throwable) {
        false
    }

    /** Shizuku is running and this app was granted permission. */
    fun isReady(): Boolean = try {
        Shizuku.pingBinder() && !Shizuku.isPreV11() &&
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) {
        false
    }

    // newProcess is not part of the public API surface any more, so it is reached by reflection.
    private val newProcess by lazy {
        Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java,
            Array<String>::class.java,
            String::class.java
        ).apply { isAccessible = true }
    }

    /** Blocking. Call from a background thread. */
    fun run(vararg cmd: String): Result {
        return try {
            val process = newProcess.invoke(null, arrayOf(*cmd), null, null) as Process
            val out = process.inputStream.bufferedReader().readText()
            val err = process.errorStream.bufferedReader().readText()
            val code = process.waitFor()
            Result(code, (out + err).trim())
        } catch (e: Throwable) {
            Result(-1, e.message ?: e.javaClass.simpleName)
        }
    }
}

/**
 * Sends touch and key input to the mirrored surface.
 * In app mode with Shizuku it uses `input -d <display>` (reliable on a virtual display);
 * otherwise it falls back to the accessibility service.
 */
object InputInjector {
    private val executor = Executors.newSingleThreadExecutor()

    private fun useShell() = MirrorState.appMode && ShizukuShell.isReady()

    fun tap(x: Float, y: Float) {
        if (useShell()) {
            val id = MirrorState.displayId.toString()
            executor.execute {
                ShizukuShell.run("input", "-d", id, "touchscreen", "tap", x.toInt().toString(), y.toInt().toString())
            }
        } else {
            MirrorAccessibilityService.instance?.tap(x, y)
        }
    }

    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long) {
        if (useShell()) {
            val id = MirrorState.displayId.toString()
            executor.execute {
                ShizukuShell.run(
                    "input", "-d", id, "touchscreen", "swipe",
                    x1.toInt().toString(), y1.toInt().toString(),
                    x2.toInt().toString(), y2.toInt().toString(),
                    durationMs.toString()
                )
            }
        } else {
            MirrorAccessibilityService.instance?.swipe(x1, y1, x2, y2, durationMs)
        }
    }

    fun back() {
        if (useShell()) {
            val id = MirrorState.displayId.toString()
            executor.execute { ShizukuShell.run("input", "-d", id, "keyevent", "4") }
        } else {
            MirrorAccessibilityService.instance?.back()
        }
    }
}
