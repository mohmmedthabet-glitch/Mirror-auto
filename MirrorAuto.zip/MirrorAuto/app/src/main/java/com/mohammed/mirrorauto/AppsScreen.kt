package com.mohammed.mirrorauto

import android.content.Intent
import androidx.car.app.CarContext
import androidx.car.app.CarToast
import androidx.car.app.Screen
import androidx.car.app.constraints.ConstraintManager
import androidx.car.app.model.Action
import androidx.car.app.model.CarIcon
import androidx.car.app.model.ItemList
import androidx.car.app.model.ListTemplate
import androidx.car.app.model.Row
import androidx.car.app.model.Template
import androidx.core.graphics.drawable.IconCompat

/** List of apps (and app pairs) that can be started from the car screen with one tap. */
class AppsScreen(carContext: CarContext) : Screen(carContext) {

    private fun listLimit(): Int = try {
        carContext.getCarService(ConstraintManager::class.java)
            .getContentLimit(ConstraintManager.CONTENT_LIMIT_TYPE_LIST)
    } catch (e: Exception) {
        6
    }

    override fun onGetTemplate(): Template {
        val entries = Favorites.carEntries(carContext, listLimit())
        val list = ItemList.Builder()
        if (entries.isEmpty()) {
            list.setNoItemsMessage("لا توجد تطبيقات. أضفها من الهاتف: اختيار تطبيق ثم إضافة إلى قائمة السيارة")
        }
        for (entry in entries) {
            val row = Row.Builder().setTitle(Favorites.label(carContext, entry))
            Favorites.icon(carContext, entry)?.let { bitmap ->
                row.setImage(CarIcon.Builder(IconCompat.createWithBitmap(bitmap)).build())
            }
            row.setOnClickListener { launch(entry) }
            list.addItem(row.build())
        }
        return ListTemplate.Builder()
            .setSingleList(list.build())
            .setTitle("التطبيقات")
            .setHeaderAction(Action.BACK)
            .build()
    }

    private fun toast(message: String) {
        CarToast.makeText(carContext, message, CarToast.LENGTH_LONG).show()
    }

    /** Starts the app (or the pair) on the phone's virtual displays, then returns to the mirror. */
    private fun launch(entry: FavoriteEntry) {
        if (!ShizukuShell.isReady()) {
            toast("Shizuku غير جاهز. شغّله على الهاتف أولًا")
            return
        }
        val intent = Intent(carContext.applicationContext, CaptureService::class.java)
            .putExtra(CaptureService.EXTRA_PACKAGE, entry.right)
        if (entry.left == null) {
            intent.setAction(CaptureService.ACTION_START_APP)
        } else {
            intent.setAction(CaptureService.ACTION_START_SPLIT)
                .putExtra(CaptureService.EXTRA_PACKAGE2, entry.left)
        }
        try {
            carContext.applicationContext.startForegroundService(intent)
            screenManager.pop()
        } catch (e: Exception) {
            toast("تعذر التشغيل من السيارة. شغّل التطبيق من الهاتف مرة واحدة ثم أعد المحاولة")
        }
    }
}
