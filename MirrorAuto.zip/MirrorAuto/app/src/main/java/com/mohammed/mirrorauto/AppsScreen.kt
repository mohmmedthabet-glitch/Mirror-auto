package com.mohammed.mirrorauto

import android.content.Intent
import androidx.car.app.CarContext
import androidx.car.app.CarToast
import androidx.car.app.Screen
import androidx.car.app.constraints.ConstraintManager
import androidx.car.app.model.Action
import androidx.car.app.model.CarIcon
import androidx.car.app.model.ItemList
import androidx.car.app.model.ListTemplate
import androidx.car.app.model.Row
import androidx.car.app.model.Template
import androidx.core.graphics.drawable.IconCompat

/** List of apps (and app pairs) that can be started from the car screen with one tap. */
class AppsScreen(carContext: CarContext) : Screen(carContext) {

    private fun listLimit(): Int = try {
        carContext.getCarService(ConstraintManager::class.java)
            .getContentLimit(ConstraintManager.CONTENT_LIMIT_TYPE_LIST)
    } catch (e: Exception) {
        6
    }

    private fun isInstalled(pkg: String): Boolean =
        carContext.packageManager.getLaunchIntentForPackage(pkg) != null

    /** The full phone-screen mirror is running (it may already have an app beside it). */
    private fun mirrorRunning() = MirrorState.running && !MirrorState.appMode

    override fun onGetTemplate(): Template {
        val limit = listLimit()
        val list = ItemList.Builder()
        var used = 0

        if (mirrorRunning()) {
            // The mirror stays running; an app opens on its right side.
            if (SplitState.active && used < limit) {
                list.addItem(actionRow("إغلاق التطبيق الجانبي والعودة للعكس الكامل") { closeSideApp() })
                used++
            }
            if (isInstalled(WAZE) && used < limit) {
                list.addItem(entryRow(FavoriteEntry(WAZE), "Waze بجانب العكس"))
                used++
            }
        } else {
            // Waze (the phone version) beside the app that is running now.
            val current = MirrorState.currentPackage
            if (MirrorState.appMode && !SplitState.active && current != null &&
                current != WAZE && isInstalled(WAZE) && used < limit
            ) {
                list.addItem(entryRow(FavoriteEntry(right = current, left = WAZE)))
                used++
            }
            if (used < limit) {
                val icon = CarIcon.Builder(IconCompat.createWithResource(carContext, R.drawable.ic_launcher)).build()
                list.addItem(
                    Row.Builder()
                        .setTitle("عكس شاشة الهاتف كاملة")
                        .setImage(icon)
                        .setOnClickListener { startFullMirror() }
                        .build()
                )
                used++
            }
        }

        val entries = Favorites.carEntries(carContext, maxOf(0, limit - used))
            .filter { !(mirrorRunning() && it.left == null && it.right == WAZE) }
        for (entry in entries) list.addItem(entryRow(entry))

        return ListTemplate.Builder()
            .setSingleList(list.build())
            .setTitle("التطبيقات")
            .setHeaderAction(Action.BACK)
            .build()
    }

    private fun actionRow(title: String, onClick: () -> Unit): Row {
        val icon = CarIcon.Builder(IconCompat.createWithResource(carContext, R.drawable.ic_launcher)).build()
        return Row.Builder().setTitle(title).setImage(icon).setOnClickListener { onClick() }.build()
    }

    private fun entryRow(entry: FavoriteEntry, title: String? = null): Row {
        val row = Row.Builder().setTitle(title ?: Favorites.label(carContext, entry))
        Favorites.icon(carContext, entry)?.let { bitmap ->
            row.setImage(CarIcon.Builder(IconCompat.createWithBitmap(bitmap)).build())
        }
        row.setOnClickListener { launch(entry) }
        return row.build()
    }

    private fun toast(message: String) {
        CarToast.makeText(carContext, message, CarToast.LENGTH_LONG).show()
    }

    private fun send(intent: Intent): Boolean = try {
        carContext.applicationContext.startForegroundService(intent)
        true
    } catch (e: Exception) {
        toast("تعذر التشغيل من السيارة. شغّل التطبيق من الهاتف مرة واحدة ثم أعد المحاولة")
        false
    }

    /**
     * Starts the app (or the pair) on the phone's virtual displays. While the full mirror is
     * running, a single app opens beside it instead, so the mirror is not stopped.
     */
    private fun launch(entry: FavoriteEntry) {
        if (!ShizukuShell.isReady()) {
            toast("Shizuku غير جاهز. شغّله على الهاتف أولًا")
            return
        }
        val intent = Intent(carContext.applicationContext, CaptureService::class.java)
            .putExtra(CaptureService.EXTRA_PACKAGE, entry.right)
        if (entry.left != null) {
            intent.setAction(CaptureService.ACTION_START_SPLIT)
                .putExtra(CaptureService.EXTRA_PACKAGE2, entry.left)
        } else if (mirrorRunning()) {
            intent.setAction(CaptureService.ACTION_ADD_PANE)
        } else {
            intent.setAction(CaptureService.ACTION_START_APP)
        }
        if (send(intent)) screenManager.pop()
    }

    private fun closeSideApp() {
        val intent = Intent(carContext.applicationContext, CaptureService::class.java)
            .setAction(CaptureService.ACTION_REMOVE_PANE)
        if (send(intent)) screenManager.pop()
    }

    /**
     * Android asks the user to confirm screen capture on the phone every time, and the car cannot
     * answer that dialog. This only brings the dialog up on the phone.
     */
    private fun startFullMirror() {
        if (ScreenPower.off) ScreenPower.set(false)
        try {
            carContext.applicationContext.startActivity(
                Intent(carContext.applicationContext, ProjectionActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            toast("وافق على نافذة مشاركة الشاشة في الهاتف. إن لم تظهر فابدأ من تطبيق الهاتف")
            screenManager.pop()
        } catch (e: Exception) {
            toast("تعذر فتح النافذة. ابدأ العكس الكامل من تطبيق الهاتف")
        }
    }

    private companion object {
        const val WAZE = "com.waze"
    }
}
